Para ejecutar exitosamente el script:

1° $ chmod +x script-Instalador-Flutter-Manjaro.sh 
2° $ ./script-Instalador-Flutter-Manjaro.sh
